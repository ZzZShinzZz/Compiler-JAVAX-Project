package intermediate.util;

public enum BackendMode 
{
    CONVERTER, EXECUTOR, COMPILER
}

public class test {

    private static int k =10;
    private static int x = 0;
    private static int y = 5;
    public static void main(String[] args) {
        System.out.println("test");

    }
}
